void initResources();
namespace LimeReport{
    void initReportItems();
    void initObjectInspectorProperties();
    void initSerializators();
    void initExporters();
} // namespace LimeReport
