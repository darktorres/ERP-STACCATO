<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>$ClassName$</name>
    <message>
        <source>$ClassName$</source>
        <translation>$ClassName$</translation>
    </message>
</context>
<context>
    <name>ChartItemEditor</name>
    <message>
        <source>Series editor</source>
        <translation>数据系列编辑器</translation>
    </message>
    <message>
        <source>Series</source>
        <translation>数据系列</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>增加</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Values field</source>
        <translation>取值字段</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Labels field</source>
        <translation>标签字段</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>Series name</source>
        <translation>系列名称</translation>
    </message>
</context>
<context>
    <name>ImageItemEditor</name>
    <message>
        <source>Image Item Editor</source>
        <translation>图像组件编辑</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>图像</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Resource path</source>
        <translation>资源路径</translation>
    </message>
    <message>
        <source>Select image file</source>
        <translation>选择图像文件</translation>
    </message>
</context>
<context>
    <name>LRVariableDialog</name>
    <message>
        <source>Variable</source>
        <translation>变量</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>注意</translation>
    </message>
    <message>
        <source>Mandatory</source>
        <translation>必要</translation>
    </message>
</context>
<context>
    <name>LanguageSelectDialog</name>
    <message>
        <source>Dialog</source>
        <translation>对话框</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>语言</translation>
    </message>
</context>
<context>
    <name>LimeReport::AboutDialog</name>
    <message>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <source>Lime Report</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;img src=&quot;:/report/images/logo_100.png&quot; height=&quot;100&quot; style=&quot;float: left;&quot; /&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;Report engine for &lt;/span&gt;&lt;span style=&quot; font-size:12pt; font-weight:600; color:#7faa18;&quot;&gt;Qt&lt;/span&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt; framework&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:11pt;&quot;&gt;LimeReport - multi-platform C++ library written using Qt framework and intended for software developers that would like to add into their application capability to form report or print forms generated using templates.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:11pt;&quot;&gt;Official web site : &lt;/span&gt;&lt;a href=&quot;www.limereport.ru&quot;&gt;&lt;span style=&quot; font-size:11pt; text-decoration: underline; color:#0000ff;&quot;&gt;www.limereport.ru&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt; text-decoration: underline; color:#0000ff;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt; font-weight:600; color:#000000;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Copyright 2015 Arin Alexander. All rights reserved.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;img src=&quot;:/report/images/logo_100.png&quot; height=&quot;100&quot; style=&quot;float: left;&quot; /&gt;&lt;span style=&quot; font-size:12pt; font-weight:600; color:#7faa18;&quot;&gt;Qt&lt;/span&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;报表引擎&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:11pt;&quot;&gt;LimeReport - QT框架多平台C++库，帮助开发者给应用增加基于模板生成报表及打印报表功能。&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:11pt;&quot;&gt;官方网站: &lt;/span&gt;&lt;a href=&quot;www.limereport.ru&quot;&gt;&lt;span style=&quot; font-size:11pt; text-decoration: underline; color:#0000ff;&quot;&gt;www.limereport.ru&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt; text-decoration: underline; color:#0000ff;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;该库基于提供帮助目的发布，但不提供任何担保，不以任何形式提供其适销性或适用于某一特定用途的默示保证。&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt; font-weight:600; color:#000000;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;版权 2015 Arin Alexander.所有权利保留.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Arin Alexander&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;arin_a@bk.ru&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>License</source>
        <translation>许可</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;(c) 2015 Arin Alexander arin_a@bk.ru&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;SEC1&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;G&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;NU LESSER GENERAL PUBLIC LICENSE&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Version 2.1, February 1999&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Copyright (C) 1991, 1999 Free Software Foundation, Inc.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Everyone is permitted to copy and distribute verbatim copies&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;of this license document, but changing it is not allowed.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;monospace&apos;;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;[This is the first released version of the Lesser GPL.  It also counts&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt; as the successor of the GNU Library Public License, version 2, hence&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt; the version number 2.1.]&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:15px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;SEC2&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;P&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;reamble&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;The licenses for most software are designed to take away your freedom to share and change it. By contrast, the GNU General Public Licenses are intended to guarantee your freedom to share and change free software--to make sure the software is free for all its users.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;This license, the Lesser General Public License, applies to some specially designated software packages--typically libraries--of the Free Software Foundation and other authors who decide to use it. You can use it too, but we suggest you first think carefully about whether this license or the ordinary General Public License is the better strategy to use in any particular case, based on the explanations below.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;When we speak of free software, we are referring to freedom of use, not price. Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for this service if you wish); that you receive source code or can get it if you want it; that you can change the software and use pieces of it in new free programs; and that you are informed that you can do these things.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;To protect your rights, we need to make restrictions that forbid distributors to deny you these rights or to ask you to surrender these rights. These restrictions translate to certain responsibilities for you if you distribute copies of the library or if you modify it.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;For example, if you distribute copies of the library, whether gratis or for a fee, you must give the recipients all the rights that we gave you. You must make sure that they, too, receive or can get the source code. If you link other code with the library, you must provide complete object files to the recipients, so that they can relink them with the library after making changes to the library and recompiling it. And you must show them these terms so they know their rights.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;We protect your rights with a two-step method: (1) we copyright the library, and (2) we offer you this license, which gives you legal permission to copy, distribute and/or modify the library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;To protect each distributor, we want to make it very clear that there is no warranty for the free library. Also, if the library is modified by someone else and passed on, the recipients should know that what they have is not the original version, so that the original author&apos;s reputation will not be affected by problems that might be introduced by others.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Finally, software patents pose a constant threat to the existence of any free program. We wish to make sure that a company cannot effectively restrict the users of a free program by obtaining a restrictive license from a patent holder. Therefore, we insist that any patent license obtained for a version of the library must be consistent with the full freedom of use specified in this license.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Most GNU software, including some libraries, is covered by the ordinary GNU General Public License. This license, the GNU Lesser General Public License, applies to certain designated libraries, and is quite different from the ordinary General Public License. We use this license for certain libraries in order to permit linking those libraries into non-free programs.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;When a program is linked with a library, whether statically or using a shared library, the combination of the two is legally speaking a combined work, a derivative of the original library. The ordinary General Public License therefore permits such linking only if the entire combination fits its criteria of freedom. The Lesser General Public License permits more lax criteria for linking other code with the library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;We call this license the &amp;quot;Lesser&amp;quot; General Public License because it does Less to protect the user&apos;s freedom than the ordinary General Public License. It also provides other free software developers Less of an advantage over competing non-free programs. These disadvantages are the reason we use the ordinary General Public License for many libraries. However, the Lesser license provides advantages in certain special circumstances.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;For example, on rare occasions, there may be a special need to encourage the widest possible use of a certain library, so that it becomes a de-facto standard. To achieve this, non-free programs must be allowed to use the library. A more frequent case is that a free library does the same job as widely used non-free libraries. In this case, there is little to gain by limiting the free library to free software only, so we use the Lesser General Public License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;In other cases, permission to use a particular library in non-free programs enables a greater number of people to use a large body of free software. For example, permission to use the GNU C Library in non-free programs enables many more people to use the whole GNU operating system, as well as its variant, the GNU/Linux operating system.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Although the Lesser General Public License is Less protective of the users&apos; freedom, it does ensure that the user of a program that is linked with the Library has the freedom and the wherewithal to run that program using a modified version of the Library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;The precise terms and conditions for copying, distribution and modification follow. Pay close attention to the difference between a &amp;quot;work based on the library&amp;quot; and a &amp;quot;work that uses the library&amp;quot;. The former contains code derived from the library, whereas the latter must be combined with the library in order to run.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:15px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;SEC3&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600; color:#333333;&quot;&gt;T&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600; color:#333333;&quot;&gt;ERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;0.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; This License Agreement applies to any software library or other program which contains a notice placed by the copyright holder or other authorized party saying it may be distributed under the terms of this Lesser General Public License (also called &amp;quot;this License&amp;quot;). Each licensee is addressed as &amp;quot;you&amp;quot;.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;A &amp;quot;library&amp;quot; means a collection of software functions and/or data prepared so as to be conveniently linked with application programs (which use some of those functions and data) to form executables.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;The &amp;quot;Library&amp;quot;, below, refers to any such software library or work which has been distributed under these terms. A &amp;quot;work based on the Library&amp;quot; means either the Library or any derivative work under copyright law: that is to say, a work containing the Library or a portion of it, either verbatim or with modifications and/or translated straightforwardly into another language. (Hereinafter, translation is included without limitation in the term &amp;quot;modification&amp;quot;.)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;&amp;quot;Source code&amp;quot; for a work means the preferred form of the work for making modifications to it. For a library, complete source code means all the source code for all modules it contains, plus any associated interface definition files, plus the scripts used to control compilation and installation of the library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Activities other than copying, distribution and modification are not covered by this License; they are outside its scope. The act of running a program using the Library is not restricted, and output from such a program is covered only if its contents constitute a work based on the Library (independent of the use of the Library in a tool for writing it). Whether that is true depends on what the Library does and what the program that uses the Library does.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;1.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You may copy and distribute verbatim copies of the Library&apos;s complete source code as you receive it, in any medium, provided that you conspicuously and appropriately publish on each copy an appropriate copyright notice and disclaimer of warranty; keep intact all the notices that refer to this License and to the absence of any warranty; and distribute a copy of this License along with the Library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;You may charge a fee for the physical act of transferring a copy, and you may at your option offer warranty protection in exchange for a fee.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;2.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You may modify your copy or copies of the Library or any portion of it, thus forming a work based on the Library, and copy and distribute such modifications or work under the terms of Section 1 above, provided that you also meet all of these conditions:&lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:19px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;a)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; The modified work must itself be a software library.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;b)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; You must cause the files modified to carry prominent notices stating that you changed the files and the date of any change.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;c)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; You must cause the whole of the work to be licensed at no charge to all third parties under the terms of this License.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:19px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;d)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; If a facility in the modified Library refers to a function or a table of data to be supplied by an application program that uses the facility, other than as an argument passed when the facility is invoked, then you must make a good faith effort to ensure that, in the event an application does not supply such function or table, the facility still operates, and performs whatever part of its purpose remains meaningful.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:15px; margin-bottom:15px; margin-left:38px; margin-right:19px; -qt-block-indent:1; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;(For example, a function in a library to compute square roots has a purpose that is entirely well-defined independent of the application. Therefore, Subsection 2d requires that any application-supplied function or table used by this function must be optional: if the application does not supply it, the square root function must still compute square roots.)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;These requirements apply to the modified work as a whole. If identifiable sections of that work are not derived from the Library, and can be reasonably considered independent and separate works in themselves, then this License, and its terms, do not apply to those sections when you distribute them as separate works. But when you distribute the same sections as part of a whole which is a work based on the Library, the distribution of the whole must be on the terms of this License, whose permissions for other licensees extend to the entire whole, and thus to each and every part regardless of who wrote it.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Thus, it is not the intent of this section to claim rights or contest your rights to work written entirely by you; rather, the intent is to exercise the right to control the distribution of derivative or collective works based on the Library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;In addition, mere aggregation of another work not based on the Library with the Library (or with a work based on the Library) on a volume of a storage or distribution medium does not bring the other work under the scope of this License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;3.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You may opt to apply the terms of the ordinary GNU General Public License instead of this License to a given copy of the Library. To do this, you must alter all the notices that refer to this License, so that they refer to the ordinary GNU General Public License, version 2, instead of to this License. (If a newer version than version 2 of the ordinary GNU General Public License has appeared, then you can specify that version instead if you wish.) Do not make any other change in these notices.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Once this change is made in a given copy, it is irreversible for that copy, so the ordinary GNU General Public License applies to all subsequent copies and derivative works made from that copy.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;This option is useful when you wish to copy part of the code of the Library into a program that is not a library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;4.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You may copy and distribute the Library (or a portion or derivative of it, under Section 2) in object code or executable form under the terms of Sections 1 and 2 above provided that you accompany it with the complete corresponding machine-readable source code, which must be distributed under the terms of Sections 1 and 2 above on a medium customarily used for software interchange.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;If distribution of object code is made by offering access to copy from a designated place, then offering equivalent access to copy the source code from the same place satisfies the requirement to distribute the source code, even though third parties are not compelled to copy the source along with the object code.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;5.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; A program that contains no derivative of any portion of the Library, but is designed to work with the Library by being compiled or linked with it, is called a &amp;quot;work that uses the Library&amp;quot;. Such a work, in isolation, is not a derivative work of the Library, and therefore falls outside the scope of this License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;However, linking a &amp;quot;work that uses the Library&amp;quot; with the Library creates an executable that is a derivative of the Library (because it contains portions of the Library), rather than a &amp;quot;work that uses the library&amp;quot;. The executable is therefore covered by this License. Section 6 states terms for distribution of such executables.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;When a &amp;quot;work that uses the Library&amp;quot; uses material from a header file that is part of the Library, the object code for the work may be a derivative work of the Library even though the source code is not. Whether this is true is especially significant if the work can be linked without the Library, or if the work is itself a library. The threshold for this to be true is not precisely defined by law.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;If such an object file uses only numerical parameters, data structure layouts and accessors, and small macros and small inline functions (ten lines or less in length), then the use of the object file is unrestricted, regardless of whether it is legally a derivative work. (Executables containing this object code plus portions of the Library will still fall under Section 6.)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Otherwise, if the work is a derivative of the Library, you may distribute the object code for the work under the terms of Section 6. Any executables containing that work also fall under Section 6, whether or not they are linked directly with the Library itself.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;6.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; As an exception to the Sections above, you may also combine or link a &amp;quot;work that uses the Library&amp;quot; with the Library to produce a work containing portions of the Library, and distribute that work under terms of your choice, provided that the terms permit modification of the work for the customer&apos;s own use and reverse engineering for debugging such modifications.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;You must give prominent notice with each copy of the work that the Library is used in it and that the Library and its use are covered by this License. You must supply a copy of this License. If the work during execution displays copyright notices, you must include the copyright notice for the Library among them, as well as a reference directing the user to the copy of this License. Also, you must do one of these things:&lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:19px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;a)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Accompany the work with the complete corresponding machine-readable source code for the Library including whatever changes were used in the work (which must be distributed under Sections 1 and 2 above); and, if the work is an executable linked with the Library, with the complete machine-readable &amp;quot;work that uses the Library&amp;quot;, as object code and/or source code, so that the user can modify the Library and then relink to produce a modified executable containing the modified Library. (It is understood that the user who changes the contents of definitions files in the Library will not necessarily be able to recompile the application to use the modified definitions.)&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;b)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Use a suitable shared library mechanism for linking with the Library. A suitable mechanism is one that (1) uses at run time a copy of the library already present on the user&apos;s computer system, rather than copying library functions into the executable, and (2) will operate properly with a modified version of the library, if the user installs one, as long as the modified version is interface-compatible with the version that the work was made with.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;c)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Accompany the work with a written offer, valid for at least three years, to give the same user the materials specified in Subsection 6a, above, for a charge no more than the cost of performing this distribution.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;d)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; If distribution of the work is made by offering access to copy from a designated place, offer equivalent access to copy the above specified materials from the same place.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:19px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;e)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Verify that the user has already received a copy of these materials or that you have already sent this user a copy.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;For an executable, the required form of the &amp;quot;work that uses the Library&amp;quot; must include any data and utility programs needed for reproducing the executable from it. However, as a special exception, the materials to be distributed need not include anything that is normally distributed (in either source or binary form) with the major components (compiler, kernel, and so on) of the operating system on which the executable runs, unless that component itself accompanies the executable.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;It may happen that this requirement contradicts the license restrictions of other proprietary libraries that do not normally accompany the operating system. Such a contradiction means you cannot use both them and the Library together in an executable that you distribute.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;7.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You may place library facilities that are a work based on the Library side-by-side in a single library together with other library facilities not covered by this License, and distribute such a combined library, provided that the separate distribution of the work based on the Library and of the other library facilities is otherwise permitted, and provided that you do these two things:&lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:19px; margin-bottom:0px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;a)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Accompany the combined library with a copy of the same work based on the Library, uncombined with any other library facilities. This must be distributed under the terms of the Sections above.&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot; font-family:&apos;sans-serif&apos;;&quot; style=&quot; margin-top:0px; margin-bottom:19px; margin-left:38px; margin-right:19px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:16px; font-weight:600;&quot;&gt;b)&lt;/span&gt;&lt;span style=&quot; font-size:16px;&quot;&gt; Give prominent notice with the combined library of the fact that part of it is a work based on the Library, and explaining where to find the accompanying uncombined form of the same work.&lt;/span&gt;&lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;8.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You may not copy, modify, sublicense, link with, or distribute the Library except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, link with, or distribute the Library is void, and will automatically terminate your rights under this License. However, parties who have received copies, or rights, from you under this License will not have their licenses terminated so long as such parties remain in full compliance.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;9.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; You are not required to accept this License, since you have not signed it. However, nothing else grants you permission to modify or distribute the Library or its derivative works. These actions are prohibited by law if you do not accept this License. Therefore, by modifying or distributing the Library (or any work based on the Library), you indicate your acceptance of this License to do so, and all its terms and conditions for copying, distributing or modifying the Library or works based on it.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;10.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; Each time you redistribute the Library (or any work based on the Library), the recipient automatically receives a license from the original licensor to copy, distribute, link with or modify the Library subject to these terms and conditions. You may not impose any further restrictions on the recipients&apos; exercise of the rights granted herein. You are not responsible for enforcing compliance by third parties with this License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;11.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; If, as a consequence of a court judgment or allegation of patent infringement or for any other reason (not limited to patent issues), conditions are imposed on you (whether by court order, agreement or otherwise) that contradict the conditions of this License, they do not excuse you from the conditions of this License. If you cannot distribute so as to satisfy simultaneously your obligations under this License and any other pertinent obligations, then as a consequence you may not distribute the Library at all. For example, if a patent license would not permit royalty-free redistribution of the Library by all those who receive copies directly or indirectly through you, then the only way you could satisfy both it and this License would be to refrain entirely from distribution of the Library.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;If any portion of this section is held invalid or unenforceable under any particular circumstance, the balance of the section is intended to apply, and the section as a whole is intended to apply in other circumstances.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;It is not the purpose of this section to induce you to infringe any patents or other property right claims or to contest validity of any such claims; this section has the sole purpose of protecting the integrity of the free software distribution system which is implemented by public license practices. Many people have made generous contributions to the wide range of software distributed through that system in reliance on consistent application of that system; it is up to the author/donor to decide if he or she is willing to distribute software through any other system and a licensee cannot impose that choice.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;This section is intended to make thoroughly clear what is believed to be a consequence of the rest of this License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;12.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; If the distribution and/or use of the Library is restricted in certain countries either by patents or by copyrighted interfaces, the original copyright holder who places the Library under this License may add an explicit geographical distribution limitation excluding those countries, so that distribution is permitted only in or among countries not thus excluded. In such case, this License incorporates the limitation as if written in the body of this License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;13.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; The Free Software Foundation may publish revised and/or new versions of the Lesser General Public License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Each version is given a distinguishing version number. If the Library specifies a version number of this License which applies to it and &amp;quot;any later version&amp;quot;, you have the option of following the terms and conditions either of that version or of any later version published by the Free Software Foundation. If the Library does not specify a license version number, you may choose any version ever published by the Free Software Foundation.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;14.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; If you wish to incorporate parts of the Library into other free programs whose distribution conditions are incompatible with these, write to the author to ask for permission. For software which is copyrighted by the Free Software Foundation, write to the Free Software Foundation; we sometimes make exceptions for this. Our decision will be guided by the two goals of preserving the free status of all derivatives of our free software and of promoting the sharing and reuse of software generally.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;NO WARRANTY&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;15.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; BECAUSE THE LIBRARY IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR THE LIBRARY, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE LIBRARY &amp;quot;AS IS&amp;quot; WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE LIBRARY IS WITH YOU. SHOULD THE LIBRARY PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600;&quot;&gt;16.&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt; IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE LIBRARY AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE LIBRARY (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE LIBRARY TO OPERATE WITH ANY OTHER SOFTWARE), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:15px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600; color:#333333;&quot;&gt;END OF TERMS AND CONDITIONS&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:15px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;SEC4&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600; color:#333333;&quot;&gt;H&lt;/span&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;; font-weight:600; color:#333333;&quot;&gt;ow to Apply These Terms to Your New Libraries&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;If you develop a new library, and you want it to be of the greatest possible use to the public, we recommend making it free software that everyone can redistribute and change. You can do so by permitting redistribution under these terms (or, alternatively, under the terms of the ordinary General Public License).&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;To apply these terms, attach the following notices to the library. It is safest to attach them to the start of each source file to most effectively convey the exclusion of warranty; and each file should have at least the &amp;quot;copyright&amp;quot; line and a pointer to where the full notice is found.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;; font-style:italic;&quot;&gt;one line to give the library&apos;s name and an idea of what it does.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Copyright (C) &lt;/span&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;; font-style:italic;&quot;&gt;year&lt;/span&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;  &lt;/span&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;; font-style:italic;&quot;&gt;name of author&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;monospace&apos;; font-style:italic;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;This library is free software; you can redistribute it and/or&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;modify it under the terms of the GNU Lesser General Public&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;License as published by the Free Software Foundation; either&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;version 2.1 of the License, or (at your option) any later version.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;monospace&apos;;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;This library is distributed in the hope that it will be useful,&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;but WITHOUT ANY WARRANTY; without even the implied warranty of&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Lesser General Public License for more details.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;monospace&apos;;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;You should have received a copy of the GNU Lesser General Public&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;License along with this library; if not, write to the Free Software&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;Also add information on how to contact you by electronic and paper mail.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;You should also get your employer (if you work as a programmer) or your school, if any, to sign a &amp;quot;copyright disclaimer&amp;quot; for the library, if necessary. Here is a sample; alter the names:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Yoyodyne, Inc., hereby disclaims all copyright interest in&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;the library `Frob&apos; (a library for tweaking knobs) written&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;by James Random Hacker.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;monospace&apos;;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;; font-style:italic;&quot;&gt;signature of Ty Coon&lt;/span&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;, 1 April 1990&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:15px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Ty Coon, President of Vice&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:19px; margin-bottom:19px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;sans-serif&apos;;&quot;&gt;That&apos;s all there is to it!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <source>Version 1.1.1</source>
        <translation>版本 1.1.1</translation>
    </message>
</context>
<context>
    <name>LimeReport::AlignmentPropItem</name>
    <message>
        <source>Left</source>
        <translation>左</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>右</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>居中</translation>
    </message>
    <message>
        <source>Justify</source>
        <translation>对齐</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>顶</translation>
    </message>
    <message>
        <source>Botom</source>
        <translation>底</translation>
    </message>
    <message>
        <source>horizontal</source>
        <translation>水平</translation>
    </message>
    <message>
        <source>vertical</source>
        <translation>垂直</translation>
    </message>
</context>
<context>
    <name>LimeReport::BandDesignIntf</name>
    <message>
        <source>DataBand</source>
        <translation>数据带</translation>
    </message>
    <message>
        <source>DataHeaderBand</source>
        <translation>数据带头</translation>
    </message>
    <message>
        <source>DataFooterBand</source>
        <translation>数据带脚</translation>
    </message>
    <message>
        <source>ReportHeader</source>
        <translation>表头</translation>
    </message>
    <message>
        <source>ReportFooter</source>
        <translation>表脚</translation>
    </message>
    <message>
        <source>PageHeader</source>
        <translation>页眉</translation>
    </message>
    <message>
        <source>PageFooter</source>
        <translation>页脚</translation>
    </message>
    <message>
        <source>SubDetailBand</source>
        <translation>子细节带</translation>
    </message>
    <message>
        <source>SubDetailHeaderBand</source>
        <translation>子细节带头</translation>
    </message>
    <message>
        <source>SubDetailFooterBand</source>
        <translation>子细节带脚</translation>
    </message>
    <message>
        <source>GroupBandHeader</source>
        <translation>组带头</translation>
    </message>
    <message>
        <source>GroupBandFooter</source>
        <translation>组带脚</translation>
    </message>
    <message>
        <source>TearOffBand</source>
        <translation>分离带</translation>
    </message>
    <message>
        <source> connected to </source>
        <translation> 连接到 </translation>
    </message>
    <message>
        <source>Bring to top</source>
        <translation>置顶</translation>
    </message>
    <message>
        <source>Send to back</source>
        <translation>置底</translation>
    </message>
    <message>
        <source>Auto height</source>
        <translation>自动高度</translation>
    </message>
    <message>
        <source>Splittable</source>
        <translation>可拆分</translation>
    </message>
    <message>
        <source>Keep bottom space</source>
        <translation>保持底部距离</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <source>Print if empty</source>
        <translation>为空时打印</translation>
    </message>
    <message>
        <source>Keep top space</source>
        <translation>保持顶部距离</translation>
    </message>
</context>
<context>
    <name>LimeReport::BaseDesignIntf</name>
    <message>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <source>Bring to top</source>
        <translation>置顶</translation>
    </message>
    <message>
        <source>Send to back</source>
        <translation>置底</translation>
    </message>
    <message>
        <source>No borders</source>
        <translation>无边框</translation>
    </message>
    <message>
        <source>All borders</source>
        <translation>所有边框</translation>
    </message>
    <message>
        <source>Create Horizontal Layout</source>
        <translation>创建水平布局</translation>
    </message>
    <message>
        <source>Lock item geometry</source>
        <translation>锁定组件形状</translation>
    </message>
    <message>
        <source>Create Vertical Layout</source>
        <translation>创建水平布局</translation>
    </message>
</context>
<context>
    <name>LimeReport::ConnectionDesc</name>
    <message>
        <source>defaultConnection</source>
        <translation>默认连接</translation>
    </message>
</context>
<context>
    <name>LimeReport::ConnectionDialog</name>
    <message>
        <source>Connection</source>
        <translation>数据连接</translation>
    </message>
    <message>
        <source>Connection Name</source>
        <translation>连接名称</translation>
    </message>
    <message>
        <source>Use default application connection</source>
        <translation>使用默认应用连接</translation>
    </message>
    <message>
        <source>Driver</source>
        <translation>驱动</translation>
    </message>
    <message>
        <source>Server </source>
        <translation>服务器 </translation>
    </message>
    <message>
        <source>Port</source>
        <translation>端口</translation>
    </message>
    <message>
        <source>User</source>
        <translation>用户名</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>数据库</translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Auto connect</source>
        <translation>自动连接</translation>
    </message>
    <message>
        <source>Check connection</source>
        <translation>检查连接</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>Connection succsesfully established!</source>
        <translation>连接成功建立!</translation>
    </message>
    <message>
        <source>Connection Name is empty</source>
        <translation>连接名为空</translation>
    </message>
    <message>
        <source>Connection with name </source>
        <translation>连接 </translation>
    </message>
    <message>
        <source> already exists! </source>
        <translation> 已经存在! </translation>
    </message>
    <message>
        <source>defaultConnection</source>
        <translation>默认连接</translation>
    </message>
    <message>
        <source>Don&apos;t keep credentials in lrxml</source>
        <translation>不在lrxml文件中保存凭证</translation>
    </message>
</context>
<context>
    <name>LimeReport::DataBand</name>
    <message>
        <source>Data</source>
        <translation>数据带</translation>
    </message>
    <message>
        <source>Use alternate background color</source>
        <translation>使用交替背景色</translation>
    </message>
    <message>
        <source>Keep footer together</source>
        <translation>保持页脚</translation>
    </message>
    <message>
        <source>Keep subdetail together</source>
        <translation>保持子细节脚</translation>
    </message>
    <message>
        <source>Slice last row</source>
        <translation>分割末行</translation>
    </message>
    <message>
        <source>Start from new page</source>
        <translation>从新页开始</translation>
    </message>
    <message>
        <source>Start new page</source>
        <translation>开始新页</translation>
    </message>
</context>
<context>
    <name>LimeReport::DataBrowser</name>
    <message>
        <source>Datasources</source>
        <translation>数据源</translation>
    </message>
    <message>
        <source>Add database connection</source>
        <translation>新建数据库连接</translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Add new datasource</source>
        <translation>新建数据源</translation>
    </message>
    <message>
        <source>View data</source>
        <translation>查看数据</translation>
    </message>
    <message>
        <source>Change datasource</source>
        <translation>编辑数据源</translation>
    </message>
    <message>
        <source>Delete datasource</source>
        <translation>删除数据源</translation>
    </message>
    <message>
        <source>Show error</source>
        <translation>显示错误</translation>
    </message>
    <message>
        <source>Variables</source>
        <translation>变量</translation>
    </message>
    <message>
        <source>Add new variable</source>
        <translation>新增变量</translation>
    </message>
    <message>
        <source>Edit variable</source>
        <translation>编辑变量</translation>
    </message>
    <message>
        <source>Delete variable</source>
        <translation>删除变量</translation>
    </message>
    <message>
        <source>Grab variable</source>
        <translation>取得变量</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>注意</translation>
    </message>
    <message>
        <source>Do you really want to delete &quot;%1&quot; connection?</source>
        <translation>是否确认删除&quot;%1&quot;连接?</translation>
    </message>
    <message>
        <source>Report variables</source>
        <translation>报表变量</translation>
    </message>
    <message>
        <source>System variables</source>
        <translation>系统变量</translation>
    </message>
    <message>
        <source>External variables</source>
        <translation>外部变量</translation>
    </message>
    <message>
        <source>Do you really want to delete &quot;%1&quot; datasource?</source>
        <translation>是否确认删除&quot;%1&quot;数据源?</translation>
    </message>
    <message>
        <source>Do you really want to delete variable &quot;%1&quot;?</source>
        <translation>是否确认删除变量&quot;%1&quot;?</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
</context>
<context>
    <name>LimeReport::DataFooterBand</name>
    <message>
        <source>DataFooter</source>
        <translation>数据带脚</translation>
    </message>
    <message>
        <source>Print always</source>
        <translation>始终打印</translation>
    </message>
</context>
<context>
    <name>LimeReport::DataHeaderBand</name>
    <message>
        <source>DataHeader</source>
        <translation>数据带头</translation>
    </message>
    <message>
        <source>Reprint on each page</source>
        <translation>重新打印每页</translation>
    </message>
    <message>
        <source>Repeat on each row</source>
        <translation>每行重复</translation>
    </message>
    <message>
        <source>Print always</source>
        <translation>始终打印</translation>
    </message>
</context>
<context>
    <name>LimeReport::DataSourceManager</name>
    <message>
        <source>Connection &quot;%1&quot; is not open</source>
        <translation>连接&quot;%1&quot;没有打开</translation>
    </message>
    <message>
        <source>Variable &quot;%1&quot; not found!</source>
        <translation>未找到变量&quot;%1&quot;!</translation>
    </message>
    <message>
        <source>Datasource &quot;%1&quot; not found!</source>
        <translation>未找到数据源&quot;%1&quot;!</translation>
    </message>
    <message>
        <source>Connection with name &quot;%1&quot; already exists!</source>
        <translation>连接 &quot;%1&quot; 已存在!</translation>
    </message>
    <message>
        <source>Datasource with name &quot;%1&quot; already exists!</source>
        <translation>数据源 &quot;%1&quot; 已存在!</translation>
    </message>
    <message>
        <source>Database &quot;%1&quot; not found</source>
        <translation>未找到数据库 &quot;%1&quot;</translation>
    </message>
    <message>
        <source>invalid connection</source>
        <translation>无效连接</translation>
    </message>
    <message>
        <source>Unknown parameter &quot;%1&quot; for variable &quot;%2&quot; found!</source>
        <translation>变量&quot;%2&quot;参数&quot;%1&quot;未知!</translation>
    </message>
</context>
<context>
    <name>LimeReport::DataSourceModel</name>
    <message>
        <source>Datasources</source>
        <translation>数据源</translation>
    </message>
    <message>
        <source>Variables</source>
        <translation>变量</translation>
    </message>
    <message>
        <source>External variables</source>
        <translation>外部变量</translation>
    </message>
</context>
<context>
    <name>LimeReport::DialogDesignerManager</name>
    <message>
        <source>Edit Widgets</source>
        <translation>编辑组件</translation>
    </message>
    <message>
        <source>Widget Box</source>
        <translation>组件盒</translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation>对象观察器</translation>
    </message>
    <message>
        <source>Property Editor</source>
        <translation>属性编辑器</translation>
    </message>
    <message>
        <source>Signals &amp;&amp; Slots Editor</source>
        <translation>信号槽编辑器</translation>
    </message>
    <message>
        <source>Resource Editor</source>
        <translation>资源编辑器</translation>
    </message>
    <message>
        <source>Action Editor</source>
        <translation>动作编辑器</translation>
    </message>
</context>
<context>
    <name>LimeReport::EnumPropItem</name>
    <message>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>纵向</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>横向</translation>
    </message>
    <message>
        <source>NoneAutoWidth</source>
        <translation>无自动宽度</translation>
    </message>
    <message>
        <source>MaxWordLength</source>
        <translation>最大词长</translation>
    </message>
    <message>
        <source>MaxStringLength</source>
        <translation>最大字符串长</translation>
    </message>
    <message>
        <source>TransparentMode</source>
        <translation>透明模式</translation>
    </message>
    <message>
        <source>OpaqueMode</source>
        <translation>不透明模式</translation>
    </message>
    <message>
        <source>Angle0</source>
        <translation>0度</translation>
    </message>
    <message>
        <source>Angle90</source>
        <translation>90度</translation>
    </message>
    <message>
        <source>Angle180</source>
        <translation>180度</translation>
    </message>
    <message>
        <source>Angle270</source>
        <translation>270度</translation>
    </message>
    <message>
        <source>Angle45</source>
        <translation>45度</translation>
    </message>
    <message>
        <source>Angle315</source>
        <translation>315度</translation>
    </message>
    <message>
        <source>DateTime</source>
        <translation>日期时间</translation>
    </message>
    <message>
        <source>Double</source>
        <translation></translation>
    </message>
    <message>
        <source>NoBrush</source>
        <translation>无</translation>
    </message>
    <message>
        <source>SolidPattern</source>
        <translation>填充</translation>
    </message>
    <message>
        <source>Dense1Pattern</source>
        <translation>密集1</translation>
    </message>
    <message>
        <source>Dense2Pattern</source>
        <translation>密集2</translation>
    </message>
    <message>
        <source>Dense3Pattern</source>
        <translation>密集3</translation>
    </message>
    <message>
        <source>Dense4Pattern</source>
        <translation>密集4</translation>
    </message>
    <message>
        <source>Dense5Pattern</source>
        <translation>密集5</translation>
    </message>
    <message>
        <source>Dense6Pattern</source>
        <translation>密集6</translation>
    </message>
    <message>
        <source>Dense7Pattern</source>
        <translation>密集7</translation>
    </message>
    <message>
        <source>HorPattern</source>
        <translation>横条纹</translation>
    </message>
    <message>
        <source>VerPattern</source>
        <translation>竖条纹</translation>
    </message>
    <message>
        <source>CrossPattern</source>
        <translation>交叉条纹</translation>
    </message>
    <message>
        <source>BDiagPattern</source>
        <translation>斜条纹</translation>
    </message>
    <message>
        <source>FDiagPattern</source>
        <translation>反斜条纹</translation>
    </message>
    <message>
        <source>LeftToRight</source>
        <translation>从左到右</translation>
    </message>
    <message>
        <source>RightToLeft</source>
        <translation>从右到左</translation>
    </message>
    <message>
        <source>LayoutDirectionAuto</source>
        <translation>自动布局方向</translation>
    </message>
    <message>
        <source>LeftItemAlign</source>
        <translation>左对齐</translation>
    </message>
    <message>
        <source>RightItemAlign</source>
        <translation>右对齐</translation>
    </message>
    <message>
        <source>CenterItemAlign</source>
        <translation>居中对齐</translation>
    </message>
    <message>
        <source>ParentWidthItemAlign</source>
        <translation>上层宽度对齐</translation>
    </message>
    <message>
        <source>DesignedItemAlign</source>
        <translation>保持设计对齐</translation>
    </message>
    <message>
        <source>HorizontalLine</source>
        <translation>水平线</translation>
    </message>
    <message>
        <source>VerticalLine</source>
        <translation>垂直线</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation>椭圆</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>矩形</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>页</translation>
    </message>
    <message>
        <source>Band</source>
        <translation>带</translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation>水平</translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation>垂直</translation>
    </message>
    <message>
        <source>VerticalUniform</source>
        <translation>均匀垂直</translation>
    </message>
    <message>
        <source>Pie</source>
        <translation>饼状图</translation>
    </message>
    <message>
        <source>VerticalBar</source>
        <translation>柱状图</translation>
    </message>
    <message>
        <source>HorizontalBar</source>
        <translation>条形图</translation>
    </message>
    <message>
        <source>LegendAlignTop</source>
        <translation>图例靠上对齐</translation>
    </message>
    <message>
        <source>LegendAlignCenter</source>
        <translation>图例居中</translation>
    </message>
    <message>
        <source>LegendAlignBottom</source>
        <translation>图例靠下对齐</translation>
    </message>
    <message>
        <source>TitleAlignLeft</source>
        <translation>标题左对齐</translation>
    </message>
    <message>
        <source>TitleAlignRight</source>
        <translation>标题右对齐</translation>
    </message>
    <message>
        <source>TitleAlignCenter</source>
        <translation>标题居中</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>布局</translation>
    </message>
    <message>
        <source>Table</source>
        <translation>表</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>毫米</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>英寸</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>比例</translation>
    </message>
    <message>
        <source>Split</source>
        <translation>划分</translation>
    </message>
</context>
<context>
    <name>LimeReport::FlagsPropItem</name>
    <message>
        <source>NoLine</source>
        <translation>无边框</translation>
    </message>
    <message>
        <source>TopLine</source>
        <translation>顶边框</translation>
    </message>
    <message>
        <source>BottomLine</source>
        <translation>底边框</translation>
    </message>
    <message>
        <source>LeftLine</source>
        <translation>左边框</translation>
    </message>
    <message>
        <source>RightLine</source>
        <translation>右边框</translation>
    </message>
    <message>
        <source>AllLines</source>
        <translation>所有边框</translation>
    </message>
</context>
<context>
    <name>LimeReport::FontEditorWidget</name>
    <message>
        <source>Font bold</source>
        <translation>粗体</translation>
    </message>
    <message>
        <source>Font Italic</source>
        <translation>斜体</translation>
    </message>
    <message>
        <source>Font Underline</source>
        <translation>下划线</translation>
    </message>
</context>
<context>
    <name>LimeReport::FontPropItem</name>
    <message>
        <source>bold</source>
        <translation>粗体</translation>
    </message>
    <message>
        <source>italic</source>
        <translation>斜体</translation>
    </message>
    <message>
        <source>underline</source>
        <translation>下划线</translation>
    </message>
    <message>
        <source>size</source>
        <translation>字号</translation>
    </message>
    <message>
        <source>family</source>
        <translation>系列</translation>
    </message>
</context>
<context>
    <name>LimeReport::GroupBandFooter</name>
    <message>
        <source>GroupFooter</source>
        <translation>组带脚</translation>
    </message>
</context>
<context>
    <name>LimeReport::GroupBandHeader</name>
    <message>
        <source>GroupHeader</source>
        <translation>组带头</translation>
    </message>
    <message>
        <source>Group field not found</source>
        <translation>未找到组字段</translation>
    </message>
    <message>
        <source>Datasource &quot;%1&quot; not found!</source>
        <translation>未找到数据源 &quot;%1&quot;!</translation>
    </message>
</context>
<context>
    <name>LimeReport::GroupFunction</name>
    <message>
        <source>Field &quot;%1&quot; not found</source>
        <translation>未找到字段 &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Variable &quot;%1&quot; not found</source>
        <translation>未找到变量 &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Wrong script syntax &quot;%1&quot; </source>
        <translation>脚本语法错误 &quot;%1&quot; </translation>
    </message>
    <message>
        <source>Item &quot;%1&quot; not found</source>
        <translation>未找到目标项 &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>LimeReport::ImageItem</name>
    <message>
        <source>Image</source>
        <translation>图像</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation>水印</translation>
    </message>
    <message>
        <source>Ext.</source>
        <translation>扩展名.</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Images (*.gif *.icns *.ico *.jpeg *.tga *.tiff *.wbmp *.webp *.png *.jpg *.bmp);;All(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LimeReport::ItemLocationPropItem</name>
    <message>
        <source>Band</source>
        <translation>带</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>页</translation>
    </message>
</context>
<context>
    <name>LimeReport::ItemsAlignmentEditorWidget</name>
    <message>
        <source>Bring to top</source>
        <translation>置顶</translation>
    </message>
    <message>
        <source>Send to back</source>
        <translation>置底</translation>
    </message>
    <message>
        <source>Align to left</source>
        <translation>左对齐</translation>
    </message>
    <message>
        <source>Align to right</source>
        <translation>右对齐</translation>
    </message>
    <message>
        <source>Align to vertical center</source>
        <translation>居中对齐</translation>
    </message>
    <message>
        <source>Align to top</source>
        <translation>顶部对齐</translation>
    </message>
    <message>
        <source>Align to bottom</source>
        <translation>底部对齐</translation>
    </message>
    <message>
        <source>Align to horizontal center</source>
        <translation>水平居中</translation>
    </message>
    <message>
        <source>Set same height</source>
        <translation>相同高度</translation>
    </message>
    <message>
        <source>Set same width</source>
        <translation>相同宽度</translation>
    </message>
</context>
<context>
    <name>LimeReport::ItemsBordersEditorWidget</name>
    <message>
        <source>Top line</source>
        <translation>顶边框</translation>
    </message>
    <message>
        <source>Bottom line</source>
        <translation>底边框</translation>
    </message>
    <message>
        <source>Left line</source>
        <translation>左边框</translation>
    </message>
    <message>
        <source>Right line</source>
        <translation>右边框</translation>
    </message>
    <message>
        <source>No borders</source>
        <translation>无边框</translation>
    </message>
    <message>
        <source>All borders</source>
        <translation>所有边框</translation>
    </message>
</context>
<context>
    <name>LimeReport::MasterDetailProxyModel</name>
    <message>
        <source>Field: &quot;%1&quot; not found in &quot;%2&quot; child datasource</source>
        <translation>从数据源 &quot;%2&quot; 中未找到字段: &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Field: &quot;%1&quot; not found in &quot;%2&quot; master datasource</source>
        <translation>主数据源 &quot;%2&quot; 中未找到字段: &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>LimeReport::ModelToDataSource</name>
    <message>
        <source>model is destroyed</source>
        <translation>数据模型已销毁</translation>
    </message>
</context>
<context>
    <name>LimeReport::ObjectBrowser</name>
    <message>
        <source>Objects</source>
        <translation>对象</translation>
    </message>
</context>
<context>
    <name>LimeReport::ObjectInspectorWidget</name>
    <message>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>筛选</translation>
    </message>
    <message>
        <source>Translate properties</source>
        <translation>翻译属性</translation>
    </message>
</context>
<context>
    <name>LimeReport::PDFExporter</name>
    <message>
        <source>Export to PDF</source>
        <translation>导出为PDF文件</translation>
    </message>
</context>
<context>
    <name>LimeReport::PageFooter</name>
    <message>
        <source>Page Footer</source>
        <translation>页脚</translation>
    </message>
    <message>
        <source>Print on first page</source>
        <translation>首页时打印</translation>
    </message>
    <message>
        <source>Print on last page</source>
        <translation>末页时打印</translation>
    </message>
</context>
<context>
    <name>LimeReport::PageHeader</name>
    <message>
        <source>Page Header</source>
        <translation>页眉</translation>
    </message>
</context>
<context>
    <name>LimeReport::PageItemDesignIntf</name>
    <message>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <source>Page is TOC</source>
        <translation>目录页面</translation>
    </message>
    <message>
        <source>Reset page number</source>
        <translation>重置页数</translation>
    </message>
    <message>
        <source>Full page</source>
        <translation>全页</translation>
    </message>
    <message>
        <source>Set page size to printer</source>
        <translation>适合打印机纸张大小</translation>
    </message>
</context>
<context>
    <name>LimeReport::PreviewReportWidget</name>
    <message>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <source>Report file name</source>
        <translation>报表文件名</translation>
    </message>
    <message>
        <source>%1 file name</source>
        <translation>文件名 %1</translation>
    </message>
</context>
<context>
    <name>LimeReport::PreviewReportWindow</name>
    <message>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <source>View</source>
        <translation>查看</translation>
    </message>
    <message>
        <source>Report</source>
        <translation>报表</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>打印</translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>放大</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>缩小</translation>
    </message>
    <message>
        <source>Prior Page</source>
        <translation>上一页</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>下一页</translation>
    </message>
    <message>
        <source>Close Preview</source>
        <translation>关闭预览</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
    <message>
        <source>Edit Mode</source>
        <translation>编辑模式</translation>
    </message>
    <message>
        <source>Save to file</source>
        <translation>保存</translation>
    </message>
    <message>
        <source>Show errors</source>
        <translation>显示错误</translation>
    </message>
    <message>
        <source>First Page</source>
        <translation>首页</translation>
    </message>
    <message>
        <source>First page</source>
        <translation>首页</translation>
    </message>
    <message>
        <source>Last Page</source>
        <translation>末页</translation>
    </message>
    <message>
        <source>Print To PDF</source>
        <translation>打印到PDF文件</translation>
    </message>
    <message>
        <source>Fit page width</source>
        <translation>适合页宽</translation>
    </message>
    <message>
        <source>Fit page</source>
        <translation>适合页高</translation>
    </message>
    <message>
        <source>One to one</source>
        <translation>原始尺寸</translation>
    </message>
    <message>
        <source>Show Toolbar</source>
        <translation>显示工具栏</translation>
    </message>
    <message>
        <source>Show toolbar</source>
        <translation>显示工具栏</translation>
    </message>
    <message>
        <source>Page: </source>
        <translation>页数: </translation>
    </message>
    <message>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Text align</source>
        <translation>文本对齐</translation>
    </message>
    <message>
        <source> of %1</source>
        <translation> / %1</translation>
    </message>
    <message>
        <source>InsertTextItem</source>
        <translation>插入文本组件</translation>
    </message>
    <message>
        <source>Add new TextItem</source>
        <translation>新增文本组件</translation>
    </message>
    <message>
        <source>Selection Mode</source>
        <translation>选择模式</translation>
    </message>
    <message>
        <source>Delete Item</source>
        <translation>删除组件</translation>
    </message>
    <message>
        <source>Del</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>MainToolBar</source>
        <translation>工具条</translation>
    </message>
    <message>
        <source>EditModeTools</source>
        <translation>编辑工具</translation>
    </message>
    <message>
        <source>Printing</source>
        <translation>正在打印</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>注意</translation>
    </message>
    <message>
        <source>The printing is in process</source>
        <translation>打印正在处理</translation>
    </message>
</context>
<context>
    <name>LimeReport::ProxyHolder</name>
    <message>
        <source>Datasource has been invalidated</source>
        <translation>数据源已失效</translation>
    </message>
</context>
<context>
    <name>LimeReport::QObjectPropertyModel</name>
    <message>
        <source>leftMargin</source>
        <translation>左边距</translation>
    </message>
    <message>
        <source>rightMargin</source>
        <translation>右边距</translation>
    </message>
    <message>
        <source>topMargin</source>
        <translation>顶边距</translation>
    </message>
    <message>
        <source>bottomMargin</source>
        <translation>底边距</translation>
    </message>
    <message>
        <source>objectName</source>
        <translation>对象名称</translation>
    </message>
    <message>
        <source>borders</source>
        <translation>边框</translation>
    </message>
    <message>
        <source>geometry</source>
        <translation>形状</translation>
    </message>
    <message>
        <source>itemAlign</source>
        <translation>对齐方式</translation>
    </message>
    <message>
        <source>pageOrientation</source>
        <translation>页面布局</translation>
    </message>
    <message>
        <source>pageSize</source>
        <translation>页面规格</translation>
    </message>
    <message>
        <source>TopLine</source>
        <translation>顶边框</translation>
    </message>
    <message>
        <source>BottomLine</source>
        <translation>底边框</translation>
    </message>
    <message>
        <source>LeftLine</source>
        <translation>左边框</translation>
    </message>
    <message>
        <source>RightLine</source>
        <translation>右边框</translation>
    </message>
    <message>
        <source>reprintOnEachPage</source>
        <translation>重新打印每页</translation>
    </message>
    <message>
        <source>borderLineSize</source>
        <translation>边框线宽</translation>
    </message>
    <message>
        <source>autoHeight</source>
        <translation>自动高度</translation>
    </message>
    <message>
        <source>backgroundColor</source>
        <translation>背景颜色</translation>
    </message>
    <message>
        <source>columnCount</source>
        <translation>列数</translation>
    </message>
    <message>
        <source>columnsFillDirection</source>
        <translation>列填充方向</translation>
    </message>
    <message>
        <source>datasource</source>
        <translation>数据源</translation>
    </message>
    <message>
        <source>keepBottomSpace</source>
        <translation>保持底部空间</translation>
    </message>
    <message>
        <source>keepFooterTogether</source>
        <translation>保持页脚</translation>
    </message>
    <message>
        <source>keepSubdetailTogether</source>
        <translation>保持子细节脚</translation>
    </message>
    <message>
        <source>printIfEmpty</source>
        <translation>为空时打印</translation>
    </message>
    <message>
        <source>sliceLastRow</source>
        <translation>分割末行</translation>
    </message>
    <message>
        <source>splittable</source>
        <translation>可拆分</translation>
    </message>
    <message>
        <source>alignment</source>
        <translation>对齐</translation>
    </message>
    <message>
        <source>angle</source>
        <translation>角度</translation>
    </message>
    <message>
        <source>autoWidth</source>
        <translation>自动宽度</translation>
    </message>
    <message>
        <source>backgroundMode</source>
        <translation>背景模式</translation>
    </message>
    <message>
        <source>backgroundOpacity</source>
        <translation>背景不透明度</translation>
    </message>
    <message>
        <source>content</source>
        <translation>内容</translation>
    </message>
    <message>
        <source>font</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>fontColor</source>
        <translation>字体颜色</translation>
    </message>
    <message>
        <source>foregroundOpacity</source>
        <translation>背景不透明度</translation>
    </message>
    <message>
        <source>itemLocation</source>
        <translation>组件位置</translation>
    </message>
    <message>
        <source>margin</source>
        <translation>边距</translation>
    </message>
    <message>
        <source>stretchToMaxHeight</source>
        <translation>拉伸到最大高度</translation>
    </message>
    <message>
        <source>trimValue</source>
        <translation>裁剪值</translation>
    </message>
    <message>
        <source>lineWidth</source>
        <translation>线宽</translation>
    </message>
    <message>
        <source>opacity</source>
        <translation>不透明度</translation>
    </message>
    <message>
        <source>penStyle</source>
        <translation>画笔样式</translation>
    </message>
    <message>
        <source>shape</source>
        <translation>形状</translation>
    </message>
    <message>
        <source>shapeBrush</source>
        <translation>画刷</translation>
    </message>
    <message>
        <source>shapeBrushColor</source>
        <translation>画刷颜色</translation>
    </message>
    <message>
        <source>gridStep</source>
        <translation>栅格长</translation>
    </message>
    <message>
        <source>fullPage</source>
        <translation>全页</translation>
    </message>
    <message>
        <source>oldPrintMode</source>
        <translation>旧打印模式</translation>
    </message>
    <message>
        <source>borderColor</source>
        <translation>边框颜色</translation>
    </message>
    <message>
        <source>resetPageNumber</source>
        <translation>重置页号</translation>
    </message>
    <message>
        <source>alternateBackgroundColor</source>
        <translation>变更背景色</translation>
    </message>
    <message>
        <source>backgroundBrushStyle</source>
        <translation>背景画刷样式</translation>
    </message>
    <message>
        <source>startFromNewPage</source>
        <translation>从新页开始</translation>
    </message>
    <message>
        <source>startNewPage</source>
        <translation>开始新页</translation>
    </message>
    <message>
        <source>adaptFontToSize</source>
        <translation>字体适应字号</translation>
    </message>
    <message>
        <source>allowHTML</source>
        <translation>允许HTML</translation>
    </message>
    <message>
        <source>allowHTMLInFields</source>
        <translation>允许字段HTML</translation>
    </message>
    <message>
        <source>followTo</source>
        <translation>跟随</translation>
    </message>
    <message>
        <source>format</source>
        <translation>格式</translation>
    </message>
    <message>
        <source>lineSpacing</source>
        <translation>线距</translation>
    </message>
    <message>
        <source>textIndent</source>
        <translation>文本缩进</translation>
    </message>
    <message>
        <source>textLayoutDirection</source>
        <translation>文本布局方向</translation>
    </message>
    <message>
        <source>underlineLineSize</source>
        <translation>下划线宽</translation>
    </message>
    <message>
        <source>underlines</source>
        <translation>下划线</translation>
    </message>
    <message>
        <source>valueType</source>
        <translation>值类型</translation>
    </message>
    <message>
        <source>securityLevel</source>
        <translation>安全级别</translation>
    </message>
    <message>
        <source>testValue</source>
        <translation>测试值</translation>
    </message>
    <message>
        <source>whitespace</source>
        <translation>空格</translation>
    </message>
    <message>
        <source>resourcePath</source>
        <translation>资源路径</translation>
    </message>
    <message>
        <source>scale</source>
        <translation>比例</translation>
    </message>
    <message>
        <source>cornerRadius</source>
        <translation>圆角半径</translation>
    </message>
    <message>
        <source>shapeColor</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>layoutType</source>
        <translation>布局类型</translation>
    </message>
    <message>
        <source>barcodeType</source>
        <translation>条码类型</translation>
    </message>
    <message>
        <source>barcodeWidth</source>
        <translation>条码宽度</translation>
    </message>
    <message>
        <source>foregroundColor</source>
        <translation>颜色</translation>
    </message>
    <message>
        <source>inputMode</source>
        <translation>输入法</translation>
    </message>
    <message>
        <source>pdf417CodeWords</source>
        <translation>PDF417码</translation>
    </message>
    <message>
        <source>autoSize</source>
        <translation>自动大小</translation>
    </message>
    <message>
        <source>center</source>
        <translation>居中</translation>
    </message>
    <message>
        <source>field</source>
        <translation>字段</translation>
    </message>
    <message>
        <source>image</source>
        <translation>图像</translation>
    </message>
    <message>
        <source>keepAspectRatio</source>
        <translation>保持比例</translation>
    </message>
    <message>
        <source>columnsCount</source>
        <translation>列数</translation>
    </message>
    <message>
        <source>useAlternateBackgroundColor</source>
        <translation>使用变更背景色</translation>
    </message>
    <message>
        <source>printBeforePageHeader</source>
        <translation>页眉前打印</translation>
    </message>
    <message>
        <source>maxScalePercent</source>
        <translation>最大百分比</translation>
    </message>
    <message>
        <source>printOnFirstPage</source>
        <translation>打印到首页</translation>
    </message>
    <message>
        <source>printOnLastPage</source>
        <translation>打印到尾页</translation>
    </message>
    <message>
        <source>printAlways</source>
        <translation>始终打印</translation>
    </message>
    <message>
        <source>repeatOnEachRow</source>
        <translation>每行重复</translation>
    </message>
    <message>
        <source>condition</source>
        <translation>条件</translation>
    </message>
    <message>
        <source>groupFieldName</source>
        <translation>组字段名</translation>
    </message>
    <message>
        <source>keepGroupTogether</source>
        <translation>保持组脚</translation>
    </message>
    <message>
        <source>Property Name</source>
        <translation>属性名</translation>
    </message>
    <message>
        <source>Property value</source>
        <translation>属性值</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <source>endlessHeight</source>
        <translation>无限高度</translation>
    </message>
    <message>
        <source>extendedHeight</source>
        <translation>扩展高度</translation>
    </message>
    <message>
        <source>isExtendedInDesignMode</source>
        <translation>设计模式扩展</translation>
    </message>
    <message>
        <source>pageIsTOC</source>
        <translation>目录页面</translation>
    </message>
    <message>
        <source>setPageSizeToPrinter</source>
        <translation>适合打印机纸张</translation>
    </message>
    <message>
        <source>fillInSecondPass</source>
        <translation>二次填充</translation>
    </message>
    <message>
        <source>chartTitle</source>
        <translation>图表标题</translation>
    </message>
    <message>
        <source>chartType</source>
        <translation>图表类型</translation>
    </message>
    <message>
        <source>drawLegendBorder</source>
        <translation>显示图例边框</translation>
    </message>
    <message>
        <source>labelsField</source>
        <translation>标签字段</translation>
    </message>
    <message>
        <source>legendAlign</source>
        <translation>图例对齐</translation>
    </message>
    <message>
        <source>series</source>
        <translation>数据系列</translation>
    </message>
    <message>
        <source>titleAlign</source>
        <translation>标题对齐</translation>
    </message>
    <message>
        <source>watermark</source>
        <translation>水印</translation>
    </message>
    <message>
        <source>keepTopSpace</source>
        <translation>保持顶部距离</translation>
    </message>
    <message>
        <source>printable</source>
        <translation>可打印</translation>
    </message>
    <message>
        <source>variable</source>
        <translation>变量</translation>
    </message>
    <message>
        <source>replaceCRwithBR</source>
        <translation>替换回车换行</translation>
    </message>
    <message>
        <source>hideIfEmpty</source>
        <translation>为空时打印</translation>
    </message>
    <message>
        <source>hideEmptyItems</source>
        <translation>隐藏空组件</translation>
    </message>
    <message>
        <source>useExternalPainter</source>
        <translation>使用外部绘图</translation>
    </message>
    <message>
        <source>layoutSpacing</source>
        <translation>布局间距</translation>
    </message>
    <message>
        <source>printerName</source>
        <translation>打印机名称</translation>
    </message>
    <message>
        <source>fontLetterSpacing</source>
        <translation>字母间距</translation>
    </message>
    <message>
        <source>hideText</source>
        <translation>隐藏文本</translation>
    </message>
    <message>
        <source>option3</source>
        <translation>选项3</translation>
    </message>
    <message>
        <source>units</source>
        <translation>单位</translation>
    </message>
    <message>
        <source>geometryLocked</source>
        <translation>形状锁定</translation>
    </message>
    <message>
        <source>printBehavior</source>
        <translation>打印行为</translation>
    </message>
    <message>
        <source>shiftItems</source>
        <translation>偏移组件</translation>
    </message>
    <message>
        <source>showLegend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>removeGap</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LimeReport::RectPropItem</name>
    <message>
        <source>width</source>
        <translation>宽</translation>
    </message>
    <message>
        <source>height</source>
        <translation>高</translation>
    </message>
</context>
<context>
    <name>LimeReport::RectUnitPropItem</name>
    <message>
        <source>width</source>
        <translation>宽</translation>
    </message>
    <message>
        <source>height</source>
        <translation>高</translation>
    </message>
</context>
<context>
    <name>LimeReport::ReportDesignWidget</name>
    <message>
        <source>Script</source>
        <translation>脚本</translation>
    </message>
    <message>
        <source>Report file name</source>
        <translation>报表文件名</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>Wrong file format</source>
        <translation>文件格式错误</translation>
    </message>
    <message>
        <source>Translations</source>
        <translation>翻译</translation>
    </message>
</context>
<context>
    <name>LimeReport::ReportDesignWindow</name>
    <message>
        <source>New Report</source>
        <translation>新建报表</translation>
    </message>
    <message>
        <source>New Report Page</source>
        <translation>新建页</translation>
    </message>
    <message>
        <source>Delete Report Page</source>
        <translation>删除页</translation>
    </message>
    <message>
        <source>Edit Mode</source>
        <translation>编辑模式</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>撤销</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <source>Use grid</source>
        <translation>使用栅格</translation>
    </message>
    <message>
        <source>Use magnet</source>
        <translation>使用磁力</translation>
    </message>
    <message>
        <source>Text Item</source>
        <translation>文本组件</translation>
    </message>
    <message>
        <source>Save Report</source>
        <translation>保存报表</translation>
    </message>
    <message>
        <source>Save Report As</source>
        <translation>另存为</translation>
    </message>
    <message>
        <source>Load Report</source>
        <translation>读取报表</translation>
    </message>
    <message>
        <source>Delete item</source>
        <translation>删除组件</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>放大</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>缩小</translation>
    </message>
    <message>
        <source>Render Report</source>
        <translation>生成报表</translation>
    </message>
    <message>
        <source>Edit layouts mode</source>
        <translation>编辑布局模式</translation>
    </message>
    <message>
        <source>Horizontal layout</source>
        <translation>水平布局</translation>
    </message>
    <message>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <source>Hide left panel | Alt+L</source>
        <translation>隐藏左面板 | Alt+L</translation>
    </message>
    <message>
        <source>Hide right panel | Alt+R</source>
        <translation>隐藏右面板 | Alt+R</translation>
    </message>
    <message>
        <source>Report Tools</source>
        <translation>报表工具</translation>
    </message>
    <message>
        <source>Main Tools</source>
        <translation>工具</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Text alignment</source>
        <translation>文本对齐</translation>
    </message>
    <message>
        <source>Items alignment</source>
        <translation>组件对齐</translation>
    </message>
    <message>
        <source>Borders</source>
        <translation>边框</translation>
    </message>
    <message>
        <source>Report bands</source>
        <translation>报表带</translation>
    </message>
    <message>
        <source>Report Header</source>
        <translation>表头</translation>
    </message>
    <message>
        <source>Report Footer</source>
        <translation>表脚</translation>
    </message>
    <message>
        <source>Page Header</source>
        <translation>页眉</translation>
    </message>
    <message>
        <source>Page Footer</source>
        <translation>页脚</translation>
    </message>
    <message>
        <source>Data</source>
        <translation>数据带</translation>
    </message>
    <message>
        <source>Data Header</source>
        <translation>数据带头</translation>
    </message>
    <message>
        <source>Data Footer</source>
        <translation>数据带脚</translation>
    </message>
    <message>
        <source>SubDetail</source>
        <translation>子细节带</translation>
    </message>
    <message>
        <source>SubDetailHeader</source>
        <translation>子细节带头</translation>
    </message>
    <message>
        <source>SubDetailFooter</source>
        <translation>子细节带脚</translation>
    </message>
    <message>
        <source>GroupHeader</source>
        <translation>组带头</translation>
    </message>
    <message>
        <source>GroupFooter</source>
        <translation>组带脚</translation>
    </message>
    <message>
        <source>Tear-off Band</source>
        <translation>分离带</translation>
    </message>
    <message>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>信息</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation>最近打开文件</translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation>对象观察器</translation>
    </message>
    <message>
        <source>Report structure</source>
        <translation>报表结构</translation>
    </message>
    <message>
        <source>Data Browser</source>
        <translation>数据浏览器</translation>
    </message>
    <message>
        <source>Script Browser</source>
        <translation>脚本浏览器</translation>
    </message>
    <message>
        <source>Report has been modified! Do you want save the report?</source>
        <translation>报表已修改! 是否保存?</translation>
    </message>
    <message>
        <source>Report file name</source>
        <translation>报表文件名</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <source>File &quot;%1&quot; not found!</source>
        <translation>未找到文件 &quot;%1&quot;!</translation>
    </message>
    <message>
        <source>Delete dialog</source>
        <translation>删除对话框</translation>
    </message>
    <message>
        <source>Add new dialog</source>
        <translation>新增对话框</translation>
    </message>
    <message>
        <source>Widget Box</source>
        <translation>组件盒</translation>
    </message>
    <message>
        <source>Property Editor</source>
        <translation>属性编辑器</translation>
    </message>
    <message>
        <source>Action Editor</source>
        <translation>动作编辑器</translation>
    </message>
    <message>
        <source>Resource Editor</source>
        <translation>资源编辑器</translation>
    </message>
    <message>
        <source>SignalSlot Editor</source>
        <translation>信号槽编辑器</translation>
    </message>
    <message>
        <source>Dialog Designer Tools</source>
        <translation>对话框设计工具</translation>
    </message>
    <message>
        <source>Vertical layout</source>
        <translation>水平布局</translation>
    </message>
    <message>
        <source>Lock selected items</source>
        <translation>锁定选定组件</translation>
    </message>
    <message>
        <source>Unlock selected items</source>
        <translation>解锁选定组件</translation>
    </message>
    <message>
        <source>Select one level items</source>
        <translation>选择一级组件</translation>
    </message>
    <message>
        <source>Rendered %1 pages</source>
        <translation>已处理%1页</translation>
    </message>
    <message>
        <source>Cancel report rendering</source>
        <translation>取消打印</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>注意</translation>
    </message>
    <message>
        <source>The rendering is in process</source>
        <translation>正在处理中</translation>
    </message>
</context>
<context>
    <name>LimeReport::ReportEnginePrivate</name>
    <message>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>Report File Change</source>
        <translation>报表文件改变</translation>
    </message>
    <message>
        <source>The report file &quot;%1&quot; has changed names or been deleted.

This preview is no longer valid.</source>
        <translation>报表文件 &quot;%1&quot; 重命名或删除。

预览已无效。</translation>
    </message>
    <message>
        <source>Designer not found!</source>
        <translation>设计器未找到！</translation>
    </message>
    <message>
        <source>Language %1 already exists</source>
        <translation>语言 %1 已存在</translation>
    </message>
    <message>
        <source>%1 file name</source>
        <translation>文件名 %1</translation>
    </message>
</context>
<context>
    <name>LimeReport::ReportFooter</name>
    <message>
        <source>Report Footer</source>
        <translation>表脚</translation>
    </message>
</context>
<context>
    <name>LimeReport::ReportHeader</name>
    <message>
        <source>Report Header</source>
        <translation>表头</translation>
    </message>
</context>
<context>
    <name>LimeReport::ReportRender</name>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>page index out of range</source>
        <translation>页索引越界</translation>
    </message>
    <message>
        <source>Databand &quot;%1&quot; not found</source>
        <translation>未找到数据带 &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Wrong using function %1</source>
        <translation>函数 %1 使用错误</translation>
    </message>
</context>
<context>
    <name>LimeReport::SQLEditDialog</name>
    <message>
        <source>Datasource</source>
        <translation>数据源</translation>
    </message>
    <message>
        <source>Connection</source>
        <translation>数据连接</translation>
    </message>
    <message>
        <source>Datasource Name</source>
        <translation>数据源名</translation>
    </message>
    <message>
        <source>Subdetail</source>
        <translation>子细节</translation>
    </message>
    <message>
        <source>Master datasource</source>
        <translation>主数据源</translation>
    </message>
    <message>
        <source>Subquery mode</source>
        <translation>子查询模式</translation>
    </message>
    <message>
        <source>Filter mode</source>
        <translation>筛选模式</translation>
    </message>
    <message>
        <source>SQL</source>
        <translation></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <source>Hide Preview</source>
        <translation>隐藏预览</translation>
    </message>
    <message>
        <source>Child datasource</source>
        <translation>子数据源</translation>
    </message>
    <message>
        <source>Fields map</source>
        <translation>字段映射</translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Data preview</source>
        <translation>数据预览</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>Datasource Name is empty!</source>
        <translation>数据源名为空!</translation>
    </message>
    <message>
        <source>SQL is empty!</source>
        <translation>SQL语句为空!</translation>
    </message>
    <message>
        <source>Datasource with name: &quot;%1&quot; already exists!</source>
        <translation>数据源 &quot;%1&quot; 已存在!</translation>
    </message>
    <message>
        <source>defaultConnection</source>
        <translation>默认连接</translation>
    </message>
    <message>
        <source>Datasource with name %1 already exist</source>
        <translation>数据源 &quot;%1&quot; 已存在</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation>注意</translation>
    </message>
    <message>
        <source>Connection is not specified</source>
        <translation>未指定连接</translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation>刷新</translation>
    </message>
    <message>
        <source>CSV</source>
        <translation>CSV</translation>
    </message>
    <message>
        <source>Separator</source>
        <translation>分隔符</translation>
    </message>
    <message>
        <source>;</source>
        <translation>；</translation>
    </message>
    <message>
        <source>Use first row as header</source>
        <translation>第一行为头</translation>
    </message>
</context>
<context>
    <name>LimeReport::SVGItem</name>
    <message>
        <source>SVG Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SVG (*.svg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished">编辑</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="unfinished">水印</translation>
    </message>
</context>
<context>
    <name>LimeReport::ScriptBrowser</name>
    <message>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <source>Functions</source>
        <translation>函数</translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Dialogs</source>
        <translation>对话框</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>NO CATEGORY</source>
        <translation>无类别</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>Dialog with name: %1 already exists</source>
        <translation>对话框 %1 已存在</translation>
    </message>
    <message>
        <source>ui file must cointain QDialog instead QWidget or QMainWindow</source>
        <translation>ui 文件必须包含 QDialog 而不是 QWidget 或 QMainWindow</translation>
    </message>
    <message>
        <source>wrong file format</source>
        <translation>文件格式错误</translation>
    </message>
</context>
<context>
    <name>LimeReport::ScriptEditor</name>
    <message>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <source>Data</source>
        <translation>数据</translation>
    </message>
    <message>
        <source>Functions</source>
        <translation>函数</translation>
    </message>
</context>
<context>
    <name>LimeReport::ScriptEngineContext</name>
    <message>
        <source>Dialog with name: %1 can`t be created</source>
        <translation>无法创建对话框 %1</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
</context>
<context>
    <name>LimeReport::ScriptEngineManager</name>
    <message>
        <source>GROUP FUNCTIONS</source>
        <translation>组函数</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <source>BandName</source>
        <translation>带名称</translation>
    </message>
    <message>
        <source>Variable %1 not found</source>
        <translation>未找到变量 %1</translation>
    </message>
    <message>
        <source>SYSTEM</source>
        <translation>系统</translation>
    </message>
    <message>
        <source>NUMBER</source>
        <translation>数字</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <source>Precision</source>
        <translation>精度</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>区域</translation>
    </message>
    <message>
        <source>DATE&amp;TIME</source>
        <translation>日期&amp;时间</translation>
    </message>
    <message>
        <source>CurrencySymbol</source>
        <translation>货币符号</translation>
    </message>
    <message>
        <source>GENERAL</source>
        <translation>通用</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <source>Function manager with name &quot;%1&quot; already exists!</source>
        <translation>函数管理器 %1 已存在！</translation>
    </message>
    <message>
        <source>FieldName</source>
        <translation>字段名</translation>
    </message>
    <message>
        <source>Field %1 not found in %2!</source>
        <translation>在 %2 中找不到字段 %1 ！</translation>
    </message>
    <message>
        <source>Datasource</source>
        <translation>数据源</translation>
    </message>
    <message>
        <source>ValueField</source>
        <translation>值字段</translation>
    </message>
    <message>
        <source>KeyField</source>
        <translation>键名字段</translation>
    </message>
    <message>
        <source>KeyFieldValue</source>
        <translation>键字段值</translation>
    </message>
    <message>
        <source>Unique identifier</source>
        <translation>唯一标识符</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>内容内容</translation>
    </message>
    <message>
        <source>Indent</source>
        <translation>缩进</translation>
    </message>
    <message>
        <source>datasourceName</source>
        <translation>数据源名称</translation>
    </message>
    <message>
        <source>RowIndex</source>
        <translation>行索引</translation>
    </message>
</context>
<context>
    <name>LimeReport::SettingDialog</name>
    <message>
        <source>Designer setting</source>
        <translation>设计器设置</translation>
    </message>
    <message>
        <source>Default font</source>
        <translation>默认字体</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>栅格</translation>
    </message>
    <message>
        <source>Vertical grid step</source>
        <translation>竖栅格</translation>
    </message>
    <message>
        <source>Horizontal grid step</source>
        <translation>横栅格</translation>
    </message>
    <message>
        <source>Suppress absent fields and variables warning</source>
        <translation>抑制缺失字段及变量警告</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <source>Designer settings</source>
        <translation>设计器设置</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>主题</translation>
    </message>
    <message>
        <source>Report units</source>
        <translation>报表单位</translation>
    </message>
    <message>
        <source>Script editor settings</source>
        <translation>脚本编辑器设置</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <source>Indent size</source>
        <translation>缩进尺寸</translation>
    </message>
    <message>
        <source>Report settings</source>
        <translation>报表设置</translation>
    </message>
</context>
<context>
    <name>LimeReport::SubDetailBand</name>
    <message>
        <source>SubDetail</source>
        <translation>子细节</translation>
    </message>
</context>
<context>
    <name>LimeReport::SubDetailHeaderBand</name>
    <message>
        <source>SubDetailHeader</source>
        <translation>子细节头</translation>
    </message>
</context>
<context>
    <name>LimeReport::SvgEditor</name>
    <message>
        <source>Select image file</source>
        <translation type="unfinished">选择图像文件</translation>
    </message>
</context>
<context>
    <name>LimeReport::TearOffBand</name>
    <message>
        <source>Tear-off Band</source>
        <translation>分离带</translation>
    </message>
</context>
<context>
    <name>LimeReport::TextAlignmentEditorWidget</name>
    <message>
        <source>Text align left</source>
        <translation>文本左对齐</translation>
    </message>
    <message>
        <source>Text align center</source>
        <translation>文本居中对齐</translation>
    </message>
    <message>
        <source>Text align right</source>
        <translation>文本右对齐</translation>
    </message>
    <message>
        <source>Text align justify</source>
        <translation>文本行对齐</translation>
    </message>
    <message>
        <source>Text align top</source>
        <translation>文本顶部对齐</translation>
    </message>
    <message>
        <source>Text align bottom</source>
        <translation>文本底部对齐</translation>
    </message>
</context>
<context>
    <name>LimeReport::TextItem</name>
    <message>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Auto height</source>
        <translation>自动高度</translation>
    </message>
    <message>
        <source>Allow HTML</source>
        <translation>允许HTML</translation>
    </message>
    <message>
        <source>Allow HTML in fields</source>
        <translation>允许字段HTML</translation>
    </message>
    <message>
        <source>Stretch to max height</source>
        <translation>拉伸至最大高度</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>TextItem &quot; %1 &quot; already has folower &quot; %2 &quot; </source>
        <translation>文本框 &quot;%1 &quot; 已有 &quot;%2 &quot; </translation>
    </message>
    <message>
        <source>TextItem &quot; %1 &quot; not found!</source>
        <translation>未找到文本框 &quot;%1&quot;!</translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation>透明</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation>水印</translation>
    </message>
    <message>
        <source>Hide if empty</source>
        <translation>为空时隐藏</translation>
    </message>
</context>
<context>
    <name>LimeReport::TextItemEditor</name>
    <message>
        <source>Text Item Editor</source>
        <translation>文本编辑器</translation>
    </message>
    <message>
        <source>Content</source>
        <translation>内容</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>Ctrl+Return</source>
        <translation></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>LimeReport::TranslationEditor</name>
    <message>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>语言</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>页</translation>
    </message>
    <message>
        <source>Strings</source>
        <translation>字符串</translation>
    </message>
    <message>
        <source>Source Text</source>
        <translation>源文</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>译文</translation>
    </message>
    <message>
        <source>Checked</source>
        <translation>选中</translation>
    </message>
    <message>
        <source>Report Item</source>
        <translation>报表组件</translation>
    </message>
    <message>
        <source>Property</source>
        <translation>属性</translation>
    </message>
    <message>
        <source>Source text</source>
        <translation>源文</translation>
    </message>
</context>
<context>
    <name>LimeReport::VariablesHolder</name>
    <message>
        <source>variable with name </source>
        <translation>变量 </translation>
    </message>
    <message>
        <source> already exists!</source>
        <translation> 已存在!</translation>
    </message>
    <message>
        <source> does not exists!</source>
        <translation> 不存在!</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Data</source>
        <translation>数据带</translation>
    </message>
    <message>
        <source>DataHeader</source>
        <translation>数据带头</translation>
    </message>
    <message>
        <source>DataFooter</source>
        <translation>数据带脚</translation>
    </message>
    <message>
        <source>GroupHeader</source>
        <translation>组带头</translation>
    </message>
    <message>
        <source>GroupFooter</source>
        <translation>组带脚</translation>
    </message>
    <message>
        <source>Page Footer</source>
        <translation>页脚</translation>
    </message>
    <message>
        <source>Page Header</source>
        <translation>页眉</translation>
    </message>
    <message>
        <source>Report Footer</source>
        <translation>表脚</translation>
    </message>
    <message>
        <source>Report Header</source>
        <translation>表头</translation>
    </message>
    <message>
        <source>SubDetail</source>
        <translation>子细节</translation>
    </message>
    <message>
        <source>SubDetailHeader</source>
        <translation>子细节头</translation>
    </message>
    <message>
        <source>SubDetailFooter</source>
        <translation>子细节带脚</translation>
    </message>
    <message>
        <source>Tear-off Band</source>
        <translation>分离带</translation>
    </message>
    <message>
        <source>alignment</source>
        <translation>对齐</translation>
    </message>
    <message>
        <source>Barcode Item</source>
        <translation>条码组件</translation>
    </message>
    <message>
        <source>HLayout</source>
        <translation>水平布局</translation>
    </message>
    <message>
        <source>Image Item</source>
        <translation>图像组件</translation>
    </message>
    <message>
        <source>Shape Item</source>
        <translation>图形组件</translation>
    </message>
    <message>
        <source>itemLocation</source>
        <translation>组件位置</translation>
    </message>
    <message>
        <source>Text Item</source>
        <translation>文本组件</translation>
    </message>
    <message>
        <source>Invalid connection! %1</source>
        <translation>无效连接 %1</translation>
    </message>
    <message>
        <source>Master datasource &quot;%1&quot; not found!</source>
        <translation>未找到主数据源 &quot;%1&quot;!</translation>
    </message>
    <message>
        <source>Master datasouce &quot;%1&quot; not found!</source>
        <translation>未找到主数据源 &quot;%1&quot;!</translation>
    </message>
    <message>
        <source>Child</source>
        <translation>子</translation>
    </message>
    <message>
        <source> and child </source>
        <translation> 子数据源 </translation>
    </message>
    <message>
        <source>datasouce &quot;%1&quot; not found!</source>
        <translation>未找到子数据源&quot;%1&quot;!</translation>
    </message>
    <message>
        <source>bool</source>
        <translation></translation>
    </message>
    <message>
        <source>QColor</source>
        <translation></translation>
    </message>
    <message>
        <source>content</source>
        <translation>内容</translation>
    </message>
    <message>
        <source>datasource</source>
        <translation>数据源</translation>
    </message>
    <message>
        <source>field</source>
        <translation>字段映射</translation>
    </message>
    <message>
        <source>enum</source>
        <translation></translation>
    </message>
    <message>
        <source>flags</source>
        <translation></translation>
    </message>
    <message>
        <source>QFont</source>
        <translation></translation>
    </message>
    <message>
        <source>QImage</source>
        <translation></translation>
    </message>
    <message>
        <source>int</source>
        <translation></translation>
    </message>
    <message>
        <source>qreal</source>
        <translation></translation>
    </message>
    <message>
        <source>QRect</source>
        <translation></translation>
    </message>
    <message>
        <source>QRectF</source>
        <translation></translation>
    </message>
    <message>
        <source>geometry</source>
        <translation>形状</translation>
    </message>
    <message>
        <source>QString</source>
        <translation></translation>
    </message>
    <message>
        <source>Attention!</source>
        <translation>注意!</translation>
    </message>
    <message>
        <source>Selected elements have different parent containers</source>
        <translation>选中元素有不同的容器</translation>
    </message>
    <message>
        <source>Object with name %1 already exists!</source>
        <translation>对象 %1 已存在!</translation>
    </message>
    <message>
        <source>Function %1 not found or have wrong arguments</source>
        <translation>未找到函数 %1 或参数错误</translation>
    </message>
    <message>
        <source>mm</source>
        <translation>毫米</translation>
    </message>
    <message>
        <source>Wrong file format</source>
        <translation>文件格式错误</translation>
    </message>
    <message>
        <source>File %1 not opened</source>
        <translation>无法打开文件 %1</translation>
    </message>
    <message>
        <source>Content string is empty</source>
        <translation>字符串为空</translation>
    </message>
    <message>
        <source>Content is empty</source>
        <translation>字符串为空</translation>
    </message>
    <message>
        <source>Chart Item</source>
        <translation>图表组件</translation>
    </message>
    <message>
        <source>First</source>
        <translation>第一</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>第二</translation>
    </message>
    <message>
        <source>Thrid</source>
        <translation>第三</translation>
    </message>
    <message>
        <source>Datasource manager not found</source>
        <translation>数据源管理器未找到</translation>
    </message>
    <message>
        <source>Export to PDF</source>
        <translation>导出为PDF文件</translation>
    </message>
    <message>
        <source>VLayout</source>
        <translation>水平布局</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>暗</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>亮</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>毫米</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>英寸</translation>
    </message>
    <message>
        <source>margin</source>
        <translation>边距</translation>
    </message>
    <message>
        <source>&apos;&apos;</source>
        <translation>&apos;&apos;</translation>
    </message>
    <message>
        <source>SVG Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>image</source>
        <translation type="unfinished">图像</translation>
    </message>
    <message>
        <source>series</source>
        <translation type="unfinished">数据系列</translation>
    </message>
    <message>
        <source>Series</source>
        <translation type="unfinished">数据系列</translation>
    </message>
</context>
</TS>
