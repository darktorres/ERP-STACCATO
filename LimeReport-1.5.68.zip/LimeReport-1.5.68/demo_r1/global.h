#ifndef GLOBAL_H
#define GLOBAL_H
#include <QString>
QString test = "ttttt";

#endif // GLOBAL_H
