#ifndef LRPAGEINITINTF_H
#define LRPAGEINITINTF_H

class IPageInit{
public:
    virtual void pageObjectHasBeenLoaded() = 0;
};

#endif // LRPAGEINITINTF_H
